<%@ page import="com.hostel.HostelDataStore, com.hostel.Notice" contentType="text/html; charset=UTF-8" %>
<%
    String user = (String) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp?msg=Please+login+first");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Notice Board</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page">
    <div class="shell">
        <div class="topbar">
            <div>
                <div class="badge">Notice Board</div>
                <h1 class="title">Latest Announcements</h1>
                <div class="subtle">Publish or view hostel notices in real time.</div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <a class="btn btn-ghost" href="services.jsp">Services</a>
                <a class="btn btn-danger" href="logout.jsp">Logout</a>
            </div>
        </div>

        <%
            String msg = request.getParameter("msg");
            if (msg != null) {
        %><div class="notice"><%= msg %></div><% } %>

        <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:18px;">
            <div class="card" style="padding:24px;">
                <h2 style="margin-top:0;">Post New Notice</h2>
                <form action="NoticeServlet" method="post" class="grid" style="gap:14px;">
                    <div class="field">
                        <label>Title *</label>
                        <input type="text" name="title" placeholder="Notice title" required>
                    </div>
                    <div class="field">
                        <label>Message *</label>
                        <textarea name="message" placeholder="Notice details" required></textarea>
                    </div>
                    <button class="btn btn-primary" type="submit">Publish Notice</button>
                </form>
            </div>

            <div class="card" style="padding:24px;">
                <h2 style="margin-top:0;">Recent Notices</h2>
                <div class="grid" style="gap:12px;">
                    <%
                        for (Notice n : HostelDataStore.getLatestNotices()) {
                    %>
                    <div class="card" style="padding:16px;background:rgba(255,255,255,.05);">
                        <div class="badge"><%= n.getCreatedAt() %></div>
                        <h3 style="margin:10px 0 6px;"><%= n.getTitle() %></h3>
                        <div class="subtle small"><%= n.getMessage() %></div>
                        <div class="small" style="margin-top:10px;color:#cbd5e1;">By <%= n.getAuthor() %></div>
                    </div>
                    <% } %>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
