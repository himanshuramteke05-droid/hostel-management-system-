<%@ page contentType="text/html; charset=UTF-8" %>
<%
    String user = (String) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp?msg=Please+login+first");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Visitor Log</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page">
    <div class="shell form-wrap">
        <div class="topbar">
            <div>
                <div class="badge">Security Log</div>
                <h1 class="title">Visitor Entry</h1>
                <div class="subtle">Keep track of guests and their purpose in a clean record form.</div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <a class="btn btn-ghost" href="services.jsp">Services</a>
                <a class="btn btn-danger" href="logout.jsp">Logout</a>
            </div>
        </div>

        <%
            String msg = request.getParameter("msg");
            if (msg != null) {
        %><div class="error"><%= msg %></div><% } %>

        <div class="card" style="padding:24px;">
            <form action="VisitorServlet" method="post" class="grid form-grid">
                <div class="field">
                    <label>Visitor Name *</label>
                    <input type="text" name="visitorName" placeholder="Enter visitor name" required>
                </div>
                <div class="field">
                    <label>Mobile</label>
                    <input type="text" name="mobile" placeholder="Contact number">
                </div>
                <div class="field">
                    <label>Purpose *</label>
                    <input type="text" name="purpose" placeholder="Meeting, delivery, parent visit..." required>
                </div>
                <div class="field">
                    <label>Relation</label>
                    <input type="text" name="relation" placeholder="Father, friend, courier...">
                </div>
                <div style="grid-column:1/-1;display:flex;gap:12px;flex-wrap:wrap;">
                    <button class="btn btn-primary" type="submit">Save Visitor</button>
                    <a class="btn btn-ghost" href="report.jsp">Recent Logs</a>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
