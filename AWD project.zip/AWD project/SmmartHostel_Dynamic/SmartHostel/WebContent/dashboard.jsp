<%@ page import="com.hostel.HostelDataStore" contentType="text/html; charset=UTF-8" %>
<%
    String user = (String) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp?msg=Please+login+first");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page">
    <div class="shell">
        <div class="topbar">
            <div>
                <div class="badge">Smart Hostel Dashboard</div>
                <h1 class="title">Hello, <%= session.getAttribute("fullName") != null ? session.getAttribute("fullName") : user %></h1>
                <div class="subtle">Role: <%= session.getAttribute("role") %> • Last update: <%= HostelDataStore.nowString() %></div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <a class="btn btn-ghost" href="services.jsp">Open Services</a>
                <a class="btn btn-danger" href="logout.jsp">Logout</a>
            </div>
        </div>

        <div class="hero card">
            <h2 style="margin:0 0 6px;">Smart hostel, all in one place</h2>
            <div class="subtle">Room booking, food, laundry, complaints, visitor log, notices and live status cards.</div>
            <div class="hero-badges">
                <span class="badge">Secure session</span>
                <span class="badge">Java Servlet MVC</span>
                <span class="badge">In-memory data engine</span>
                <span class="badge">Responsive UI</span>
            </div>
        </div>

        <div class="grid stat-grid" style="margin-top:18px;">
            <div class="card stat"><p>Total Students</p><h3><%= HostelDataStore.getTotalStudents() %></h3></div>
            <div class="card stat"><p>Room Bookings</p><h3><%= HostelDataStore.getTotalBookings() %></h3></div>
            <div class="card stat"><p>Food Orders</p><h3><%= HostelDataStore.getTotalFoodOrders() %></h3></div>
            <div class="card stat"><p>Laundry Requests</p><h3><%= HostelDataStore.getTotalLaundryOrders() %></h3></div>
            <div class="card stat"><p>Complaints</p><h3><%= HostelDataStore.getTotalComplaints() %></h3></div>
            <div class="card stat"><p>Visitor Logs</p><h3><%= HostelDataStore.getTotalVisitors() %></h3></div>
        </div>

        <div class="grid menu-grid" style="margin-top:18px;">
            <a class="menu-card" href="room.jsp"><span class="badge">01</span><h3>Room Booking</h3><p>Reserve rooms with floor, sharing and duration details.</p></a>
            <a class="menu-card" href="food.jsp"><span class="badge">02</span><h3>Food Services</h3><p>Order meals with breakfast, lunch, dinner and special requests.</p></a>
            <a class="menu-card" href="laundry.jsp"><span class="badge">03</span><h3>Laundry</h3><p>Send clothes list, urgent flag and estimated charges.</p></a>
            <a class="menu-card" href="complaint.jsp"><span class="badge">04</span><h3>Complaint Desk</h3><p>Register maintenance, electricity, water or mess issues.</p></a>
            <a class="menu-card" href="visitor.jsp"><span class="badge">05</span><h3>Visitor Entry</h3><p>Track guests with contact number, purpose and relation.</p></a>
            <a class="menu-card" href="notice.jsp"><span class="badge">06</span><h3>Notice Board</h3><p>Post and view hostel circulars from one dashboard.</p></a>
            <a class="menu-card" href="bill.jsp"><span class="badge">07</span><h3>Bill Estimate</h3><p>See a combined hostel cost estimate with quick summary.</p></a>
            <a class="menu-card" href="report.jsp"><span class="badge">08</span><h3>Reports</h3><p>Review recent records and a live summary of activities.</p></a>
            <a class="menu-card" href="wifi.jsp"><span class="badge">09</span><h3>Wi-Fi Details</h3><p>Display network credentials and room support information.</p></a>
        </div>
    </div>
</div>
</body>
</html>
