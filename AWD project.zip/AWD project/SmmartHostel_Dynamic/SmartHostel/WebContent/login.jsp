<%@ page import="com.hostel.HostelDataStore" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Smart Hostel Login</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="center-screen">
    <div class="card auth-card">
        <div class="badge">Smart Hostel </div>
        <h1>Welcome Back</h1>
        <p>Login to manage rooms, complaints, visitors, food, laundry and notices from one dashboard.</p>

        <%
            String msg = request.getParameter("msg");
            if (msg != null && !msg.trim().isEmpty()) {
        %>
        <div class="<%= msg.toLowerCase().contains("invalid") ? "error" : "notice" %>"><%= msg %></div>
        <% } %>

        <form action="LoginServlet" method="post" class="grid" style="gap:14px;">
            <div class="field">
                <label>Username</label>
                <input type="text" name="username" placeholder="admin / student" required>
            </div>
            <div class="field">
                <label>Password</label>
                <input type="password" name="password" placeholder="admin123" required>
            </div>
            <button class="btn btn-primary" type="submit">Login</button>
        </form>

        <div class="hero-badges">
            <span class="badge">Admin: admin / admin123</span>
            <span class="badge">Demo: student / student123</span>
        </div>

        <p class="footer-note">New user? <a href="register.jsp" style="color:#7dd3fc;">Create account</a></p>
    </div>
</div>
</body>
</html>
