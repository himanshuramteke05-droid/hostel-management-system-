<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String title = (String) request.getAttribute("title");
    String message = (String) request.getAttribute("message");
    String amount = (String) request.getAttribute("amount");
    String nextPage = (String) request.getAttribute("nextPage");
    if (title == null) title = "Success";
    if (message == null) message = "Your request was completed.";
    if (amount == null) amount = "Saved successfully";
    if (nextPage == null) nextPage = "services.jsp";
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><%= title %></title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="center-screen">
    <div class="card auth-card" style="width:min(700px,100%);text-align:center;">
        <div class="badge">Operation Complete</div>
        <h1><%= title %></h1>
        <p><%= message %></p>
        <div class="hero" style="margin:18px 0;">
            <div class="subtle">Status</div>
            <h2 style="margin:8px 0 0;"><%= amount %></h2>
        </div>
        <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">
            <a class="btn btn-primary" href="<%= nextPage %>">Continue</a>
            <a class="btn btn-ghost" href="dashboard.jsp">Dashboard</a>
        </div>
    </div>
</div>
</body>
</html>
