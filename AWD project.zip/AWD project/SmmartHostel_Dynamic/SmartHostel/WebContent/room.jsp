<%@ page import="com.hostel.HostelDataStore" contentType="text/html; charset=UTF-8" %>
<%
    String user = (String) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp?msg=Please+login+first");
        return;
    }
    String msg = request.getParameter("msg");
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Room Booking</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page">
    <div class="shell form-wrap">
        <div class="topbar">
            <div>
                <div class="badge">Room Allocation</div>
                <h1 class="title">Book a Room</h1>
                <div class="subtle">Choose room type, floor and stay duration. The estimate is calculated automatically.</div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <a class="btn btn-ghost" href="services.jsp">Services</a>
                <a class="btn btn-danger" href="logout.jsp">Logout</a>
            </div>
        </div>

        <% if (msg != null) { %><div class="error"><%= msg %></div><% } %>

        <div class="card" style="padding:24px;">
            <form action="RoomBookingServlet" method="post" class="grid form-grid">
                <div class="field">
                    <label>Student Name</label>
                    <input type="text" name="studentName" value="<%= session.getAttribute("fullName") != null ? session.getAttribute("fullName") : "" %>" placeholder="Auto-filled from login">
                </div>
                <div class="field">
                    <label>Room Type *</label>
                    <select name="roomType" required>
                        <option value="">Select</option>
                        <option>Single Deluxe</option>
                        <option>Double Premium</option>
                        <option>Standard</option>
                        <option>Executive</option>
                    </select>
                </div>
                <div class="field">
                    <label>Floor</label>
                    <select name="floor">
                        <option>Ground Floor</option>
                        <option>1st Floor</option>
                        <option>2nd Floor</option>
                        <option>3rd Floor</option>
                    </select>
                </div>
                <div class="field">
                    <label>Sharing</label>
                    <select name="sharing">
                        <option>Single</option>
                        <option>Double</option>
                        <option>Triple</option>
                    </select>
                </div>
                <div class="field">
                    <label>Start Date</label>
                    <input type="date" name="date" required>
                </div>
                <div class="field">
                    <label>No. of Days</label>
                    <input type="number" min="1" name="days" value="1" required>
                </div>
                <div style="grid-column:1/-1;display:flex;gap:12px;flex-wrap:wrap;">
                    <button class="btn btn-primary" type="submit">Book Room</button>
                    <a class="btn btn-ghost" href="bill.jsp">View Bill</a>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
