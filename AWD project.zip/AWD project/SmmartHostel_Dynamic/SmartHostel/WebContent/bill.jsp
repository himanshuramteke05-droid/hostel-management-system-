<%@ page import="com.hostel.HostelDataStore" contentType="text/html; charset=UTF-8" %>
<%
    String user = (String) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp?msg=Please+login+first");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Bill Estimate</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page">
    <div class="shell">
        <div class="topbar">
            <div>
                <div class="badge">Billing Summary</div>
                <h1 class="title">Estimated Hostel Cost</h1>
                <div class="subtle">A simple demo bill combining room, food and laundry estimate.</div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <a class="btn btn-ghost" href="services.jsp">Services</a>
                <a class="btn btn-danger" href="logout.jsp">Logout</a>
            </div>
        </div>

        <%
            double room = HostelDataStore.estimateRoomAmount("Double Premium", "Double", 5);
            double food = HostelDataStore.estimateFoodAmount("Breakfast + Lunch", 5);
            double laundry = HostelDataStore.estimateLaundryAmount("5 shirts, 2 jeans", "No");
            double total = room + food + laundry;
        %>

        <div class="grid stat-grid">
            <div class="card stat"><p>Room Estimate</p><h3><%= HostelDataStore.formatCurrency(room) %></h3></div>
            <div class="card stat"><p>Food Estimate</p><h3><%= HostelDataStore.formatCurrency(food) %></h3></div>
            <div class="card stat"><p>Laundry Estimate</p><h3><%= HostelDataStore.formatCurrency(laundry) %></h3></div>
            <div class="card stat"><p>Total Estimate</p><h3><%= HostelDataStore.formatCurrency(total) %></h3></div>
        </div>

        <div class="card" style="padding:24px;margin-top:18px;">
            <h2 style="margin-top:0;">Breakup</h2>
            <div class="table-wrap">
                <table>
                    <tr><th>Component</th><th>Details</th><th>Amount</th></tr>
                    <tr><td>Room</td><td>Double Premium • 5 days</td><td><%= HostelDataStore.formatCurrency(room) %></td></tr>
                    <tr><td>Food</td><td>Breakfast + Lunch • 5 days</td><td><%= HostelDataStore.formatCurrency(food) %></td></tr>
                    <tr><td>Laundry</td><td>5 shirts, 2 jeans</td><td><%= HostelDataStore.formatCurrency(laundry) %></td></tr>
                    <tr><td><b>Total</b></td><td>Estimated hostel services bill</td><td><b><%= HostelDataStore.formatCurrency(total) %></b></td></tr>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
