<%@ page contentType="text/html; charset=UTF-8" %>
<%
    String user = (String) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp?msg=Please+login+first");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Wi-Fi Details</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="center-screen">
    <div class="card auth-card" style="width:min(760px,100%);">
        <div class="badge">Network Support</div>
        <h1>Wi-Fi Details</h1>
        <p>Hostel Wi-Fi access information and quick support reference.</p>

        <div class="grid stat-grid">
            <div class="card stat"><p>SSID</p><h3>SmartHostel-5G</h3></div>
            <div class="card stat"><p>Password</p><h3>hostel@123</h3></div>
            <div class="card stat"><p>Support</p><h3>Room Office</h3></div>
            <div class="card stat"><p>Timing</p><h3>24×7</h3></div>
        </div>

        <div class="footer-note">For connectivity issues, log a complaint from the dashboard.</div>
        <div style="margin-top:16px;display:flex;gap:10px;flex-wrap:wrap;">
            <a class="btn btn-primary" href="services.jsp">Back to Services</a>
            <a class="btn btn-ghost" href="report.jsp">See Reports</a>
        </div>
    </div>
</div>
</body>
</html>
