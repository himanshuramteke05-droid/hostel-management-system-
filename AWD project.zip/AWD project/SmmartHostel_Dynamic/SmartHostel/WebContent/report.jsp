<%@ page import="com.hostel.HostelDataStore, com.hostel.RoomBooking, com.hostel.FoodOrder, com.hostel.LaundryOrder, com.hostel.Complaint, com.hostel.VisitorLog" contentType="text/html; charset=UTF-8" %>
<%
    String user = (String) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp?msg=Please+login+first");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Reports</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page">
    <div class="shell">
        <div class="topbar">
            <div>
                <div class="badge">Live Report</div>
                <h1 class="title">Activity Summary</h1>
                <div class="subtle">Recent entries and counts pulled from the in-memory project engine.</div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <a class="btn btn-ghost" href="services.jsp">Services</a>
                <a class="btn btn-danger" href="logout.jsp">Logout</a>
            </div>
        </div>

        <div class="grid stat-grid">
            <div class="card stat"><p>Students</p><h3><%= HostelDataStore.getTotalStudents() %></h3></div>
            <div class="card stat"><p>Bookings</p><h3><%= HostelDataStore.getTotalBookings() %></h3></div>
            <div class="card stat"><p>Complaints</p><h3><%= HostelDataStore.getTotalComplaints() %></h3></div>
            <div class="card stat"><p>Visitors</p><h3><%= HostelDataStore.getTotalVisitors() %></h3></div>
        </div>

        <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:18px;margin-top:18px;">
            <div class="card" style="padding:24px;">
                <h2 style="margin-top:0;">Recent Bookings</h2>
                <div class="table-wrap">
                    <table>
                        <tr><th>Name</th><th>Room</th><th>Days</th><th>Amount</th></tr>
                        <%
                            for (RoomBooking r : HostelDataStore.getLatestBookings()) {
                        %>
                        <tr>
                            <td><%= r.getStudentName() %></td>
                            <td><%= r.getRoomType() %></td>
                            <td><%= r.getDays() %></td>
                            <td><%= HostelDataStore.formatCurrency(r.getAmount()) %></td>
                        </tr>
                        <% } %>
                    </table>
                </div>
            </div>

            <div class="card" style="padding:24px;">
                <h2 style="margin-top:0;">Recent Complaints</h2>
                <div class="table-wrap">
                    <table>
                        <tr><th>Type</th><th>Priority</th><th>Status</th></tr>
                        <%
                            for (Complaint c : HostelDataStore.getLatestComplaints()) {
                        %>
                        <tr>
                            <td><%= c.getType() %></td>
                            <td><%= c.getPriority() %></td>
                            <td><%= c.getStatus() %></td>
                        </tr>
                        <% } %>
                    </table>
                </div>
            </div>

            <div class="card" style="padding:24px;">
                <h2 style="margin-top:0;">Recent Food Orders</h2>
                <div class="table-wrap">
                    <table>
                        <tr><th>Meals</th><th>Days</th><th>Amount</th></tr>
                        <%
                            for (FoodOrder f : HostelDataStore.getLatestFoodOrders()) {
                        %>
                        <tr>
                            <td><%= f.getMeals() %></td>
                            <td><%= f.getDays() %></td>
                            <td><%= HostelDataStore.formatCurrency(f.getAmount()) %></td>
                        </tr>
                        <% } %>
                    </table>
                </div>
            </div>

            <div class="card" style="padding:24px;">
                <h2 style="margin-top:0;">Visitors</h2>
                <div class="table-wrap">
                    <table>
                        <tr><th>Name</th><th>Purpose</th><th>Time</th></tr>
                        <%
                            for (VisitorLog v : HostelDataStore.getLatestVisitors()) {
                        %>
                        <tr>
                            <td><%= v.getVisitorName() %></td>
                            <td><%= v.getPurpose() %></td>
                            <td><%= v.getCreatedAt() %></td>
                        </tr>
                        <% } %>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
