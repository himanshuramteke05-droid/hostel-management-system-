<%@ page import="com.hostel.HostelDataStore" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>System Check</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="center-screen">
    <div class="card auth-card" style="width:min(720px,100%);">
        <div class="badge">System Check</div>
        <h1>Project Health</h1>
        <p>This page confirms that the Smart Hostel engine is live and the in-memory data store is working.</p>

        <div class="grid stat-grid" style="margin-top:18px;">
            <div class="card stat"><p>Storage Engine</p><h3>Ready</h3></div>
            <div class="card stat"><p>User Count</p><h3><%= HostelDataStore.getTotalStudents() %></h3></div>
            <div class="card stat"><p>Notices</p><h3><%= HostelDataStore.getTotalNotices() %></h3></div>
            <div class="card stat"><p>Status</p><h3>OK</h3></div>
        </div>

        <div class="hero" style="margin-top:18px;">
            <div class="subtle">Summary</div>
            <h2 style="margin:8px 0 0;"><%= HostelDataStore.summarize() %></h2>
        </div>

        <div style="margin-top:16px;display:flex;gap:10px;flex-wrap:wrap;justify-content:center;">
            <a class="btn btn-primary" href="login.jsp">Login</a>
            <a class="btn btn-ghost" href="dashboard.jsp">Dashboard</a>
        </div>
    </div>
</div>
</body>
</html>
