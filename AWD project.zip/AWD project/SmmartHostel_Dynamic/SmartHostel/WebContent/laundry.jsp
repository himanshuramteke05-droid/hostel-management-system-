<%@ page contentType="text/html; charset=UTF-8" %>
<%
    String user = (String) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp?msg=Please+login+first");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Laundry Service</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page">
    <div class="shell form-wrap">
        <div class="topbar">
            <div>
                <div class="badge">Laundry Desk</div>
                <h1 class="title">Laundry Request</h1>
                <div class="subtle">Add cloth items and choose urgent pickup for faster processing.</div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <a class="btn btn-ghost" href="services.jsp">Services</a>
                <a class="btn btn-danger" href="logout.jsp">Logout</a>
            </div>
        </div>

        <%
            String msg = request.getParameter("msg");
            if (msg != null) {
        %><div class="error"><%= msg %></div><% } %>

        <div class="card" style="padding:24px;">
            <form action="LaundryServlet" method="post" class="grid form-grid">
                <div class="field">
                    <label>Student Name</label>
                    <input type="text" name="studentName" value="<%= session.getAttribute("fullName") != null ? session.getAttribute("fullName") : "" %>">
                </div>
                <div class="field">
                    <label>Items</label>
                    <textarea name="items" placeholder="Example: 5 shirts, 2 jeans, 1 jacket" required></textarea>
                </div>
                <div class="field">
                    <label>Urgent Pickup</label>
                    <select name="urgent">
                        <option>No</option>
                        <option>Yes</option>
                    </select>
                </div>
                <div class="field">
                    <label>Preferred Slot</label>
                    <select name="slot">
                        <option>Morning</option>
                        <option>Afternoon</option>
                        <option>Evening</option>
                    </select>
                </div>
                <div style="grid-column:1/-1;display:flex;gap:12px;flex-wrap:wrap;">
                    <button class="btn btn-primary" type="submit">Submit Laundry Request</button>
                    <a class="btn btn-ghost" href="bill.jsp">Check Estimate</a>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
