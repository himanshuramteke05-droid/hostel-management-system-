<%@ page import="com.hostel.HostelDataStore" contentType="text/html; charset=UTF-8" %>
<%
    String user = (String) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp?msg=Please+login+first");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Hostel Services</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page">
    <div class="shell">
        <div class="topbar">
            <div>
                <div class="badge">Services Hub</div>
                <h1 class="title">All Hostel Tools</h1>
                <div class="subtle">Fast access to every feature. Same project, better structure, better presentation.</div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <a class="btn btn-ghost" href="dashboard.jsp">Dashboard</a>
                <a class="btn btn-danger" href="logout.jsp">Logout</a>
            </div>
        </div>

        <div class="grid menu-grid">
            <a class="menu-card" href="room.jsp"><h3>Room Booking</h3><p>Allocation request and estimate.</p></a>
            <a class="menu-card" href="food.jsp"><h3>Food Menu</h3><p>Meal ordering with custom request.</p></a>
            <a class="menu-card" href="laundry.jsp"><h3>Laundry Service</h3><p>Shirt, jeans, urgent pickup, pricing.</p></a>
            <a class="menu-card" href="complaint.jsp"><h3>Complaint Box</h3><p>Raise hostel maintenance tickets.</p></a>
            <a class="menu-card" href="visitor.jsp"><h3>Visitor Entry</h3><p>Guest log with purpose and relation.</p></a>
            <a class="menu-card" href="notice.jsp"><h3>Notice Board</h3><p>Read and publish announcements.</p></a>
            <a class="menu-card" href="bill.jsp"><h3>Bill Summary</h3><p>Total estimate with service breakdown.</p></a>
            <a class="menu-card" href="report.jsp"><h3>Reports</h3><p>Recent entries and quick stats.</p></a>
            <a class="menu-card" href="wifi.jsp"><h3>Wi-Fi</h3><p>Network details and help desk info.</p></a>
            <a class="menu-card" href="testDB.jsp"><h3>System Check</h3><p>Project health and storage status.</p></a>
        </div>

        <div class="footer-note">Logged in as <b><%= session.getAttribute("fullName") != null ? session.getAttribute("fullName") : user %></b>. Total notices: <%= HostelDataStore.getTotalNotices() %>.</div>
    </div>
</div>
</body>
</html>
