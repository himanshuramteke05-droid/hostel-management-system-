<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Create Account</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="center-screen">
    <div class="card auth-card" style="width:min(760px,100%);">
        <div class="badge">Student Registration</div>
        <h1 style="margin-top:10px;">Create Hostel Account</h1>
        <p>Register once and access all hostel services inside the same project.</p>

        <%
            String msg = request.getParameter("msg");
            if (msg != null && !msg.trim().isEmpty()) {
        %>
        <div class="error"><%= msg %></div>
        <% } %>

        <form action="RegisterServlet" method="post" class="grid form-grid">
            <div class="field">
                <label>Full Name *</label>
                <input type="text" name="fullName" placeholder="Your full name" required>
            </div>
            <div class="field">
                <label>Username *</label>
                <input type="text" name="username" placeholder="Create username" required>
            </div>
            <div class="field">
                <label>Password *</label>
                <input type="password" name="password" placeholder="Create password" required>
            </div>
            <div class="field">
                <label>Mobile</label>
                <input type="text" name="mobile" placeholder="10 digit number">
            </div>
            <div class="field">
                <label>Room Preference</label>
                <select name="roomPreference">
                    <option value="Single">Single</option>
                    <option value="Double">Double</option>
                    <option value="Deluxe">Deluxe</option>
                </select>
            </div>
            <div class="field">
                <label>Course / Department</label>
                <input type="text" name="course" placeholder="MCA / BSc / BTech">
            </div>
            <div style="grid-column:1/-1;display:flex;gap:12px;flex-wrap:wrap;">
                <button class="btn btn-success" type="submit">Create Account</button>
                <a class="btn btn-ghost" href="login.jsp">Back to Login</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>
