<%@ page contentType="text/html; charset=UTF-8" %>
<%
    String user = (String) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp?msg=Please+login+first");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Complaint Desk</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page">
    <div class="shell form-wrap">
        <div class="topbar">
            <div>
                <div class="badge">Help Desk</div>
                <h1 class="title">Register Complaint</h1>
                <div class="subtle">Maintenance, water, electricity, internet or mess complaints.</div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <a class="btn btn-ghost" href="services.jsp">Services</a>
                <a class="btn btn-danger" href="logout.jsp">Logout</a>
            </div>
        </div>

        <%
            String msg = request.getParameter("msg");
            if (msg != null) {
        %><div class="error"><%= msg %></div><% } %>

        <div class="card" style="padding:24px;">
            <form action="ComplaintServlet" method="post" class="grid form-grid">
                <div class="field">
                    <label>Student Name</label>
                    <input type="text" name="studentName" value="<%= session.getAttribute("fullName") != null ? session.getAttribute("fullName") : "" %>">
                </div>
                <div class="field">
                    <label>Complaint Type *</label>
                    <select name="type" required>
                        <option value="">Select</option>
                        <option>Electricity</option>
                        <option>Water</option>
                        <option>Internet</option>
                        <option>Cleanliness</option>
                        <option>Food</option>
                        <option>Furniture</option>
                    </select>
                </div>
                <div class="field">
                    <label>Priority</label>
                    <select name="priority">
                        <option>Low</option>
                        <option>Medium</option>
                        <option selected>High</option>
                    </select>
                </div>
                <div class="field">
                    <label>Description *</label>
                    <textarea name="message" placeholder="Describe the issue in detail" required></textarea>
                </div>
                <div style="grid-column:1/-1;display:flex;gap:12px;flex-wrap:wrap;">
                    <button class="btn btn-primary" type="submit">Submit Complaint</button>
                    <a class="btn btn-ghost" href="report.jsp">See Status</a>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
