<%@ page import="com.hostel.HostelDataStore" contentType="text/html; charset=UTF-8" %>
<%
    String user = (String) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp?msg=Please+login+first");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Food Service</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page">
    <div class="shell form-wrap">
        <div class="topbar">
            <div>
                <div class="badge">Mess Services</div>
                <h1 class="title">Food Order</h1>
                <div class="subtle">Pick meals and add special instructions for the kitchen staff.</div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <a class="btn btn-ghost" href="services.jsp">Services</a>
                <a class="btn btn-danger" href="logout.jsp">Logout</a>
            </div>
        </div>

        <%
            String msg = request.getParameter("msg");
            if (msg != null) {
        %><div class="error"><%= msg %></div><% } %>

        <div class="card" style="padding:24px;">
            <form action="FoodServlet" method="post" class="grid form-grid">
                <div class="field">
                    <label>Student Name</label>
                    <input type="text" name="studentName" value="<%= session.getAttribute("fullName") != null ? session.getAttribute("fullName") : "" %>">
                </div>
                <div class="field">
                    <label>Meal Type</label>
                    <select name="mealType">
                        <option>Breakfast</option>
                        <option>Lunch</option>
                        <option>Dinner</option>
                        <option>Breakfast + Lunch</option>
                        <option>Lunch + Dinner</option>
                        <option>Full Day</option>
                    </select>
                </div>
                <div class="field">
                    <label>No. of Days</label>
                    <input type="number" min="1" name="days" value="1" required>
                </div>
                <div class="field">
                    <label>Special Request</label>
                    <input type="text" name="specialRequest" placeholder="Less spicy, no onion, etc.">
                </div>

                <div class="field" style="grid-column:1/-1;">
                    <label>Quick Meal Checkboxes</label>
                    <div style="display:flex;gap:18px;flex-wrap:wrap;padding:8px 0;color:#cbd5e1;">
                        <label><input type="checkbox" name="breakfast" value="1"> Breakfast</label>
                        <label><input type="checkbox" name="lunch" value="1"> Lunch</label>
                        <label><input type="checkbox" name="dinner" value="1"> Dinner</label>
                        <label><input type="checkbox" name="snacks" value="1"> Snacks</label>
                    </div>
                </div>

                <div style="grid-column:1/-1;display:flex;gap:12px;flex-wrap:wrap;">
                    <button class="btn btn-primary" type="submit">Save Food Order</button>
                    <a class="btn btn-ghost" href="report.jsp">Recent Orders</a>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
