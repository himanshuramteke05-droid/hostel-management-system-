SmartHostel - Eclipse Dynamic Web Project

Import in Eclipse:
1. File > Import > Existing Projects into Workspace
2. Select the SmartHostel folder (the folder that contains src and WebContent)
3. Finish
4. Right click project > Properties > Targeted Runtimes
5. Tick Apache Tomcat v9.0
6. Run As > Run on Server

Login:
admin / admin123
student / student123
