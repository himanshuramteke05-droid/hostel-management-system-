package com.hostel;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        System.out.println("Servlet hit hua"); // DEBUG

        String fullName = HostelDataStore.safe(request.getParameter("fullName"));
        String username = HostelDataStore.safe(request.getParameter("username")).toLowerCase();
        String password = HostelDataStore.safe(request.getParameter("password"));
        String mobile = HostelDataStore.safe(request.getParameter("mobile"));
        String roomPreference = HostelDataStore.safe(request.getParameter("roomPreference"));
        String course = HostelDataStore.safe(request.getParameter("course"));

        if (HostelDataStore.isBlank(fullName) || HostelDataStore.isBlank(username) || HostelDataStore.isBlank(password)) {
            response.sendRedirect("register.jsp?msg=Please+fill+all+required+fields");
            return;
        }

        boolean ok = HostelDataStore.register(new User(fullName, username, password, roomPreference, mobile, "STUDENT"));

      
        try {
            Connection con = DBConnection.getConnection();
            System.out.println("Connection: " + con); 

            if (con == null) {
                System.out.println("DB connection NULL hai ❌");
            } else {
                String query = "INSERT INTO students(fullName, username, password) VALUES (?, ?, ?)";

                PreparedStatement ps = con.prepareStatement(query);
                ps.setString(1, fullName);
                ps.setString(2, username);
                ps.setString(3, password);

                int rows = ps.executeUpdate();
                System.out.println("Inserted rows: " + rows); 
            }

        } catch (Exception e) {
            System.out.println("ERROR AAYA ❌");
            e.printStackTrace();
        }

        if (!ok) {
            response.sendRedirect("register.jsp?msg=Username+already+exists+or+invalid+data");
            return;
        }

        HttpSession session = request.getSession(true);
        session.setAttribute("user", username);
        session.setAttribute("fullName", fullName);
        session.setAttribute("role", "STUDENT");
        session.setAttribute("course", course);

        response.sendRedirect("dashboard.jsp?msg=Account+created+successfully");
    }
}