package com.hostel;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ComplaintServlet")
public class ComplaintServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        String studentName = session != null && session.getAttribute("fullName") != null
                ? String.valueOf(session.getAttribute("fullName"))
                : HostelDataStore.safe(request.getParameter("studentName"));

        String type = HostelDataStore.safe(request.getParameter("type"));
        String priority = HostelDataStore.safe(request.getParameter("priority"));
        String message = HostelDataStore.safe(request.getParameter("message"));

        if (HostelDataStore.isBlank(type) || HostelDataStore.isBlank(message)) {
            response.sendRedirect("complaint.jsp?msg=Please+fill+all+required+fields");
            return;
        }

        Complaint complaint = new Complaint(studentName, type, priority, message, "Open", HostelDataStore.nowString());
        HostelDataStore.addComplaint(complaint);

        request.setAttribute("title", "Complaint Registered");
        request.setAttribute("message", type + " | Priority: " + priority);
        request.setAttribute("amount", "Ticket ID Created");
        request.setAttribute("nextPage", "services.jsp");
        request.getRequestDispatcher("success.jsp").forward(request, response);
    }
}
