package com.hostel;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/hostel",
                "root",
                ""
            );

            System.out.println("DB Connected ✔️");
            return con;

        } catch (Exception e) {
            System.out.println("DB Connection Failed ❌");
            e.printStackTrace();
            return null;
        }
    }
}