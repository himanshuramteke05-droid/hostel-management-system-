package com.hostel;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LaundryServlet")
public class LaundryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        String studentName = session != null && session.getAttribute("fullName") != null
                ? String.valueOf(session.getAttribute("fullName"))
                : HostelDataStore.safe(request.getParameter("studentName"));

        String items = HostelDataStore.safe(request.getParameter("items"));
        String urgent = HostelDataStore.safe(request.getParameter("urgent"));
        if (HostelDataStore.isBlank(items)) {
            response.sendRedirect("laundry.jsp?msg=Enter+laundry+items");
            return;
        }

        double amount = HostelDataStore.estimateLaundryAmount(items, urgent);
        LaundryOrder order = new LaundryOrder(studentName, items, urgent, amount, HostelDataStore.nowString());
        HostelDataStore.addLaundryOrder(order);

        request.setAttribute("title", "Laundry Request Submitted");
        request.setAttribute("message", items + " | Urgent: " + urgent);
        request.setAttribute("amount", HostelDataStore.formatCurrency(amount));
        request.setAttribute("nextPage", "services.jsp");
        request.getRequestDispatcher("success.jsp").forward(request, response);
    }
}
