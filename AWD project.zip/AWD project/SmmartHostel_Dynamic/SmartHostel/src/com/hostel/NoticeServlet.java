package com.hostel;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/NoticeServlet")
public class NoticeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        String author = session != null && session.getAttribute("fullName") != null
                ? String.valueOf(session.getAttribute("fullName"))
                : "System";
        String title = HostelDataStore.safe(request.getParameter("title"));
        String message = HostelDataStore.safe(request.getParameter("message"));

        if (HostelDataStore.isBlank(title) || HostelDataStore.isBlank(message)) {
            response.sendRedirect("notice.jsp?msg=Please+enter+title+and+message");
            return;
        }

        HostelDataStore.addNotice(new Notice(title, message, author, HostelDataStore.nowString()));
        response.sendRedirect("notice.jsp?msg=Notice+published+successfully");
    }
}
