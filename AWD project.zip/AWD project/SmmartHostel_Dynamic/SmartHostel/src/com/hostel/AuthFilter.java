package com.hostel;

import java.io.IOException;
import java.util.Set;
import java.util.HashSet;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebFilter("/*")
public class AuthFilter extends HttpFilter implements Filter {
    private static final long serialVersionUID = 1L;
    private static final Set<String> PUBLIC_PATHS = new HashSet<String>();

    static {
        PUBLIC_PATHS.add("/SmartHostel/");
        PUBLIC_PATHS.add("/SmartHostel/index.jsp");
        PUBLIC_PATHS.add("/SmartHostel/login.jsp");
        PUBLIC_PATHS.add("/SmartHostel/register.jsp");
        PUBLIC_PATHS.add("/SmartHostel/LoginServlet");
        PUBLIC_PATHS.add("/SmartHostel/RegisterServlet");
        PUBLIC_PATHS.add("/SmartHostel/logout.jsp");
        PUBLIC_PATHS.add("/SmartHostel/LogoutServlet");
        PUBLIC_PATHS.add("/SmartHostel/testDB.jsp");
        PUBLIC_PATHS.add("/SmartHostel/assets/");
    }

    @Override
    public void doFilter(javax.servlet.ServletRequest req, javax.servlet.ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        String uri = request.getRequestURI();
        String ctx = request.getContextPath();

        if (isPublic(uri, ctx) || uri.endsWith(".css") || uri.endsWith(".js") || uri.endsWith(".png")
                || uri.endsWith(".jpg") || uri.endsWith(".jpeg") || uri.endsWith(".gif")) {
            chain.doFilter(req, res);
            return;
        }

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp?msg=Please+login+first");
            return;
        }

        chain.doFilter(req, res);
    }

    private boolean isPublic(String uri, String ctx) {
        if (uri.equals(ctx + "/") || uri.equals(ctx)) return true;
        if (uri.startsWith(ctx + "/assets/")) return true;
        for (String p : PUBLIC_PATHS) {
            if (uri.equals(p)) return true;
        }
        return false;
    }
}
