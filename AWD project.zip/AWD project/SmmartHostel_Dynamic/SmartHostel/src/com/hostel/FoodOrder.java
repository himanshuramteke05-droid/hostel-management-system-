package com.hostel;

import java.io.Serializable;

public class FoodOrder implements Serializable {
    private static final long serialVersionUID = 1L;

    private String studentName;
    private String meals;
    private int days;
    private String specialRequest;
    private double amount;
    private String createdAt;

    public FoodOrder() {
    }

    public FoodOrder(String studentName, String meals, int days, String specialRequest, double amount, String createdAt) {
        this.studentName = studentName;
        this.meals = meals;
        this.days = days;
        this.specialRequest = specialRequest;
        this.amount = amount;
        this.createdAt = createdAt;
    }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getMeals() { return meals; }
    public void setMeals(String meals) { this.meals = meals; }

    public int getDays() { return days; }
    public void setDays(int days) { this.days = days; }

    public String getSpecialRequest() { return specialRequest; }
    public void setSpecialRequest(String specialRequest) { this.specialRequest = specialRequest; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

}
