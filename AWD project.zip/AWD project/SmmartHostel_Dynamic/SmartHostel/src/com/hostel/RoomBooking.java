package com.hostel;

import java.io.Serializable;

public class RoomBooking implements Serializable {
    private static final long serialVersionUID = 1L;

    private String studentName;
    private String roomType;
    private String floor;
    private String sharing;
    private String startDate;
    private int days;
    private double amount;
    private String createdAt;

    public RoomBooking() {
    }

    public RoomBooking(String studentName, String roomType, String floor, String sharing, String startDate, int days, double amount, String createdAt) {
        this.studentName = studentName;
        this.roomType = roomType;
        this.floor = floor;
        this.sharing = sharing;
        this.startDate = startDate;
        this.days = days;
        this.amount = amount;
        this.createdAt = createdAt;
    }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getRoomType() { return roomType; }
    public void setRoomType(String roomType) { this.roomType = roomType; }

    public String getFloor() { return floor; }
    public void setFloor(String floor) { this.floor = floor; }

    public String getSharing() { return sharing; }
    public void setSharing(String sharing) { this.sharing = sharing; }

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public int getDays() { return days; }
    public void setDays(int days) { this.days = days; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

}
