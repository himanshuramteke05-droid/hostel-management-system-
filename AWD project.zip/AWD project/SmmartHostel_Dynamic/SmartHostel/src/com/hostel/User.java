package com.hostel;

import java.io.Serializable;

public class User implements Serializable {
    private static final long serialVersionUID = 1L;

    private String fullName;
    private String username;
    private String password;
    private String roomPreference;
    private String mobile;
    private String role;

    public User() {
    }

    public User(String fullName, String username, String password, String roomPreference, String mobile, String role) {
        this.fullName = fullName;
        this.username = username;
        this.password = password;
        this.roomPreference = roomPreference;
        this.mobile = mobile;
        this.role = role;
    }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRoomPreference() { return roomPreference; }
    public void setRoomPreference(String roomPreference) { this.roomPreference = roomPreference; }

    public String getMobile() { return mobile; }
    public void setMobile(String mobile) { this.mobile = mobile; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
}
