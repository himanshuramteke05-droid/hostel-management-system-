package com.hostel;

import java.io.Serializable;

public class VisitorLog implements Serializable {
    private static final long serialVersionUID = 1L;

    private String visitorName;
    private String mobile;
    private String purpose;
    private String relation;
    private String createdAt;

    public VisitorLog() {
    }

    public VisitorLog(String visitorName, String mobile, String purpose, String relation, String createdAt) {
        this.visitorName = visitorName;
        this.mobile = mobile;
        this.purpose = purpose;
        this.relation = relation;
        this.createdAt = createdAt;
    }

    public String getVisitorName() { return visitorName; }
    public void setVisitorName(String visitorName) { this.visitorName = visitorName; }

    public String getMobile() { return mobile; }
    public void setMobile(String mobile) { this.mobile = mobile; }

    public String getPurpose() { return purpose; }
    public void setPurpose(String purpose) { this.purpose = purpose; }

    public String getRelation() { return relation; }
    public void setRelation(String relation) { this.relation = relation; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

}
