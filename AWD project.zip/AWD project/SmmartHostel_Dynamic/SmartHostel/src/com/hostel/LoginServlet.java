package com.hostel;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = HostelDataStore.safe(request.getParameter("username"));
        String password = HostelDataStore.safe(request.getParameter("password"));

        User user = HostelDataStore.authenticate(username, password);
        if (user == null) {
            response.sendRedirect("login.jsp?msg=Invalid+username+or+password");
            return;
        }

        HttpSession session = request.getSession(true);
        session.setAttribute("user", user.getUsername());
        session.setAttribute("fullName", user.getFullName());
        session.setAttribute("role", user.getRole());
        response.sendRedirect("dashboard.jsp");
    }
}
