package com.hostel;

import java.io.Serializable;

public class Complaint implements Serializable {
    private static final long serialVersionUID = 1L;

    private String studentName;
    private String type;
    private String priority;
    private String message;
    private String status;
    private String createdAt;

    public Complaint() {
    }

    public Complaint(String studentName, String type, String priority, String message, String status, String createdAt) {
        this.studentName = studentName;
        this.type = type;
        this.priority = priority;
        this.message = message;
        this.status = status;
        this.createdAt = createdAt;
    }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

}
