package com.hostel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public final class HostelDataStore {
    private static final Map<String, User> USERS = new ConcurrentHashMap<>();
    private static final List<RoomBooking> BOOKINGS = new CopyOnWriteArrayList<>();
    private static final List<FoodOrder> FOOD_ORDERS = new CopyOnWriteArrayList<>();
    private static final List<LaundryOrder> LAUNDRY_ORDERS = new CopyOnWriteArrayList<>();
    private static final List<Complaint> COMPLAINTS = new CopyOnWriteArrayList<>();
    private static final List<VisitorLog> VISITORS = new CopyOnWriteArrayList<>();
    private static final List<Notice> NOTICES = new CopyOnWriteArrayList<>();

    static {
        USERS.put("admin", new User("Hostel Admin", "admin", "admin123", "N/A", "9999999999", "ADMIN"));
        USERS.put("student", new User("Demo Student", "student", "student123", "Single", "8888888888", "STUDENT"));

        addNoticeInternal(new Notice("Welcome to Smart Hostel",
                "Clean rooms, smart services, online requests and live updates are enabled for this demo project.",
                "System", now()));
        addNoticeInternal(new Notice("Mess Timing",
                "Breakfast 7:30 AM - 9:00 AM, Lunch 12:30 PM - 2:00 PM, Dinner 7:30 PM - 9:30 PM.",
                "Mess Warden", now()));
        addNoticeInternal(new Notice("Laundry Reminder",
                "Laundry requests placed before 6 PM will be processed on the same day.",
                "Laundry Desk", now()));

        BOOKINGS.add(new RoomBooking("Aman Kumar", "Deluxe", "2nd Floor", "Double", "2026-04-15", 7, 11200, now()));
        FOOD_ORDERS.add(new FoodOrder("Aman Kumar", "Breakfast + Lunch", 5, "Less spicy", 750, now()));
        LAUNDRY_ORDERS.add(new LaundryOrder("Aman Kumar", "5 Shirts, 2 Jeans", "No", 180, now()));
        COMPLAINTS.add(new Complaint("Aman Kumar", "Electricity", "High", "Fan not working properly in room 212", "Open", now()));
        VISITORS.add(new VisitorLog("Rahul Sharma", "9876543210", "Parent meeting", "Father", now()));
    }

    private HostelDataStore() {}

    private static String now() {
        return new SimpleDateFormat("dd MMM yyyy, hh:mm a").format(new Date());
    }

    public static synchronized boolean register(User user) {
        if (user == null || isBlank(user.getUsername()) || isBlank(user.getPassword())) {
            return false;
        }
        if (USERS.containsKey(user.getUsername().toLowerCase())) {
            return false;
        }
        user.setUsername(user.getUsername().toLowerCase());
        if (isBlank(user.getFullName())) {
            user.setFullName(capitalize(user.getUsername()));
        }
        if (isBlank(user.getRole())) {
            user.setRole("STUDENT");
        }
        USERS.put(user.getUsername(), user);
        return true;
    }

    public static User authenticate(String username, String password) {
        if (isBlank(username) || isBlank(password)) {
            return null;
        }
        User user = USERS.get(username.toLowerCase());
        if (user != null && password.equals(user.getPassword())) {
            return user;
        }
        return null;
    }

    public static synchronized RoomBooking addRoomBooking(RoomBooking booking) {
        BOOKINGS.add(booking);
        return booking;
    }

    public static synchronized FoodOrder addFoodOrder(FoodOrder order) {
        FOOD_ORDERS.add(order);
        return order;
    }

    public static synchronized LaundryOrder addLaundryOrder(LaundryOrder order) {
        LAUNDRY_ORDERS.add(order);
        return order;
    }

    public static synchronized Complaint addComplaint(Complaint complaint) {
        COMPLAINTS.add(complaint);
        return complaint;
    }

    public static synchronized VisitorLog addVisitor(VisitorLog visitorLog) {
        VISITORS.add(visitorLog);
        return visitorLog;
    }

    public static synchronized Notice addNotice(Notice notice) {
        addNoticeInternal(notice);
        return notice;
    }

    private static void addNoticeInternal(Notice notice) {
        NOTICES.add(0, notice);
    }

    public static int getTotalStudents() {
        return USERS.size();
    }

    public static int getTotalBookings() {
        return BOOKINGS.size();
    }

    public static int getTotalFoodOrders() {
        return FOOD_ORDERS.size();
    }

    public static int getTotalLaundryOrders() {
        return LAUNDRY_ORDERS.size();
    }

    public static int getTotalComplaints() {
        return COMPLAINTS.size();
    }

    public static int getTotalVisitors() {
        return VISITORS.size();
    }

    public static int getTotalNotices() {
        return NOTICES.size();
    }

    public static List<RoomBooking> getLatestBookings() {
        return latest(BOOKINGS, 5);
    }

    public static List<FoodOrder> getLatestFoodOrders() {
        return latest(FOOD_ORDERS, 5);
    }

    public static List<LaundryOrder> getLatestLaundryOrders() {
        return latest(LAUNDRY_ORDERS, 5);
    }

    public static List<Complaint> getLatestComplaints() {
        return latest(COMPLAINTS, 5);
    }

    public static List<VisitorLog> getLatestVisitors() {
        return latest(VISITORS, 5);
    }

    public static List<Notice> getLatestNotices() {
        return latest(NOTICES, 8);
    }

    private static <T> List<T> latest(List<T> source, int limit) {
        List<T> copy = new ArrayList<>(source);
        Collections.reverse(copy);
        if (copy.size() > limit) {
            return new ArrayList<>(copy.subList(0, limit));
        }
        return copy;
    }

    public static Map<String, Integer> getQuickStats() {
        Map<String, Integer> stats = new LinkedHashMap<>();
        stats.put("Students", getTotalStudents());
        stats.put("Bookings", getTotalBookings());
        stats.put("Food", getTotalFoodOrders());
        stats.put("Laundry", getTotalLaundryOrders());
        stats.put("Complaints", getTotalComplaints());
        stats.put("Visitors", getTotalVisitors());
        return stats;
    }

    public static double estimateRoomAmount(String roomType, String sharing, int days) {
        double base;
        String rt = safe(roomType).toLowerCase();
        if (rt.contains("deluxe")) base = 1800;
        else if (rt.contains("double")) base = 1200;
        else base = 950;

        if (safe(sharing).toLowerCase().contains("single")) base += 400;
        if (days <= 0) days = 1;
        return base * days;
    }

    public static double estimateFoodAmount(String meals, int days) {
        int perDay = 0;
        String m = safe(meals).toLowerCase();
        if (m.contains("breakfast")) perDay += 60;
        if (m.contains("lunch")) perDay += 90;
        if (m.contains("dinner")) perDay += 100;
        if (perDay == 0) perDay = 75;
        if (days <= 0) days = 1;
        return perDay * days;
    }

    public static double estimateLaundryAmount(String items, String urgent) {
        int pieces = countItems(items);
        double amount = Math.max(pieces * 18.0, 90);
        if (safe(urgent).equalsIgnoreCase("Yes")) {
            amount += 50;
        }
        return amount;
    }

    public static int countItems(String items) {
        if (isBlank(items)) return 0;
        String[] parts = items.split("[,;\n]");
        int count = 0;
        for (String p : parts) {
            if (!isBlank(p)) count++;
        }
        return Math.max(count, 1);
    }

    public static String nowString() {
        return now();
    }

    public static String safe(String s) {
        return s == null ? "" : s.trim();
    }

    public static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    public static String capitalize(String s) {
        s = safe(s);
        if (s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    public static String formatCurrency(double amount) {
        return String.format("₹%,.0f", amount);
    }

    public static String summarize() {
        return "Students: " + getTotalStudents() + ", Bookings: " + getTotalBookings() + ", Food: " + getTotalFoodOrders()
                + ", Laundry: " + getTotalLaundryOrders() + ", Complaints: " + getTotalComplaints() + ", Visitors: " + getTotalVisitors();
    }
}
