package com.hostel;

import java.io.Serializable;

public class LaundryOrder implements Serializable {
    private static final long serialVersionUID = 1L;

    private String studentName;
    private String items;
    private String urgent;
    private double amount;
    private String createdAt;

    public LaundryOrder() {
    }

    public LaundryOrder(String studentName, String items, String urgent, double amount, String createdAt) {
        this.studentName = studentName;
        this.items = items;
        this.urgent = urgent;
        this.amount = amount;
        this.createdAt = createdAt;
    }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getItems() { return items; }
    public void setItems(String items) { this.items = items; }

    public String getUrgent() { return urgent; }
    public void setUrgent(String urgent) { this.urgent = urgent; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

}
