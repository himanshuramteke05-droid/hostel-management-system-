package com.hostel;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/VisitorServlet")
public class VisitorServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        String visitorName = HostelDataStore.safe(request.getParameter("visitorName"));
        String mobile = HostelDataStore.safe(request.getParameter("mobile"));
        String purpose = HostelDataStore.safe(request.getParameter("purpose"));
        String relation = HostelDataStore.safe(request.getParameter("relation"));

        if (HostelDataStore.isBlank(visitorName) || HostelDataStore.isBlank(purpose)) {
            response.sendRedirect("visitor.jsp?msg=Please+fill+visitor+name+and+purpose");
            return;
        }

        VisitorLog visitorLog = new VisitorLog(visitorName, mobile, purpose, relation, HostelDataStore.nowString());
        HostelDataStore.addVisitor(visitorLog);

        request.setAttribute("title", "Visitor Logged");
        request.setAttribute("message", visitorName + " | Purpose: " + purpose);
        request.setAttribute("amount", "Entry Saved");
        request.setAttribute("nextPage", "services.jsp");
        request.getRequestDispatcher("success.jsp").forward(request, response);
    }
}
