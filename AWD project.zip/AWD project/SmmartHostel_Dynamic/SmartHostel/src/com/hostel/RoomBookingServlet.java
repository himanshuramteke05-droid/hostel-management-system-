package com.hostel;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/RoomBookingServlet")
public class RoomBookingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        String studentName = session != null && session.getAttribute("fullName") != null
                ? String.valueOf(session.getAttribute("fullName"))
                : HostelDataStore.safe(request.getParameter("studentName"));

        String roomType = HostelDataStore.safe(request.getParameter("roomType"));
        String floor = HostelDataStore.safe(request.getParameter("floor"));
        String sharing = HostelDataStore.safe(request.getParameter("sharing"));
        String startDate = HostelDataStore.safe(request.getParameter("date"));
        int days = parseInt(request.getParameter("days"), 1);

        if (HostelDataStore.isBlank(roomType)) {
            response.sendRedirect("room.jsp?msg=Select+a+room+type");
            return;
        }

        double amount = HostelDataStore.estimateRoomAmount(roomType, sharing, days);
        RoomBooking booking = new RoomBooking(studentName, roomType, floor, sharing, startDate, days, amount, HostelDataStore.nowString());
        HostelDataStore.addRoomBooking(booking);

        request.setAttribute("title", "Room Booked Successfully");
        request.setAttribute("message", "Room type: " + roomType + " | Floor: " + floor + " | Sharing: " + sharing);
        request.setAttribute("amount", HostelDataStore.formatCurrency(amount));
        request.setAttribute("nextPage", "services.jsp");
        RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
        rd.forward(request, response);
    }

    private int parseInt(String value, int fallback) {
        try {
            return Integer.parseInt(value);
        } catch (Exception ex) {
            return fallback;
        }
    }
}
