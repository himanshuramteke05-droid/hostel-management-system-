package com.hostel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/FoodServlet")
public class FoodServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        String studentName = session != null && session.getAttribute("fullName") != null
                ? String.valueOf(session.getAttribute("fullName"))
                : HostelDataStore.safe(request.getParameter("studentName"));

        List<String> selected = new ArrayList<>();
        if (request.getParameter("breakfast") != null) selected.add("Breakfast");
        if (request.getParameter("lunch") != null) selected.add("Lunch");
        if (request.getParameter("dinner") != null) selected.add("Dinner");
        if (request.getParameter("snacks") != null) selected.add("Snacks");

        String meals = selected.isEmpty() ? HostelDataStore.safe(request.getParameter("mealType")) : String.join(" + ", selected);
        String specialRequest = HostelDataStore.safe(request.getParameter("specialRequest"));
        int days = parseInt(request.getParameter("days"), 1);

        if (HostelDataStore.isBlank(meals)) {
            response.sendRedirect("food.jsp?msg=Select+at+least+one+meal");
            return;
        }

        double amount = HostelDataStore.estimateFoodAmount(meals, days);
        FoodOrder order = new FoodOrder(studentName, meals, days, specialRequest, amount, HostelDataStore.nowString());
        HostelDataStore.addFoodOrder(order);

        request.setAttribute("title", "Food Order Saved");
        request.setAttribute("message", meals + (HostelDataStore.isBlank(specialRequest) ? "" : " | Request: " + specialRequest));
        request.setAttribute("amount", HostelDataStore.formatCurrency(amount));
        request.setAttribute("nextPage", "services.jsp");
        request.getRequestDispatcher("success.jsp").forward(request, response);
    }

    private int parseInt(String value, int fallback) {
        try {
            return Integer.parseInt(value);
        } catch (Exception ex) {
            return fallback;
        }
    }
}
